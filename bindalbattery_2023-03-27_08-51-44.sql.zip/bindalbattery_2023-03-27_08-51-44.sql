-- MariaDB dump 10.19  Distrib 10.5.10-MariaDB, for Win64 (AMD64)
--
-- Host: p3nlmysql123plsk.secureserver.net    Database: bindalbattery
-- ------------------------------------------------------
-- Server version	5.7.26-29-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applicationuser`
--

DROP TABLE IF EXISTS `applicationuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applicationuser` (
  `ApplicationUserId` int(11) NOT NULL AUTO_INCREMENT,
  `PartyName` varchar(200) NOT NULL,
  `Passcode` varchar(10) DEFAULT NULL,
  `Place` varchar(200) NOT NULL,
  `Mobile` bigint(20) NOT NULL,
  `IsActive` varchar(45) DEFAULT NULL,
  `CreateDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` varchar(45) DEFAULT '(''System'')',
  `role` varchar(20) NOT NULL,
  PRIMARY KEY (`ApplicationUserId`),
  UNIQUE KEY `idx_mobile` (`Mobile`),
  KEY `Pk_ApplicationUserId` (`ApplicationUserId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicationuser`
--

LOCK TABLES `applicationuser` WRITE;
/*!40000 ALTER TABLE `applicationuser` DISABLE KEYS */;
INSERT INTO `applicationuser` VALUES (4,'Sandeep Kumar','1234','Kanpur',9873309067,'true','2023-01-30 06:38:34','pankaj',''),(7,'Pankaj Kumar','@39939','Kanpur',9873309037,'true','2023-01-30 06:38:34','pankaj',''),(8,'Amit Kumar','@39939','Kanpur',9873309447,'true','2023-01-30 06:38:34','pankaj','');
/*!40000 ALTER TABLE `applicationuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partymaster`
--

DROP TABLE IF EXISTS `partymaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partymaster` (
  `PartyMasterId` int(11) NOT NULL AUTO_INCREMENT,
  `GracePeriod` int(11) NOT NULL,
  `CreateDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` varchar(45) DEFAULT '(''System'')',
  `mobile` bigint(20) DEFAULT NULL,
  `Partyname` varchar(200) DEFAULT NULL,
  `place` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`PartyMasterId`),
  KEY `Pk_PartyMasterId` (`PartyMasterId`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partymaster`
--

LOCK TABLES `partymaster` WRITE;
/*!40000 ALTER TABLE `partymaster` DISABLE KEYS */;
INSERT INTO `partymaster` VALUES (15,30,'2023-01-31 07:51:01','(\'System\')',9873309033,'Audotmative battery','Gaziabad'),(18,90,'2023-01-31 07:51:01','(\'System\')',9873309022,'Shyama battery','Noida'),(22,36,'2023-01-31 22:12:19','System',9745633234,'Yello Battery','Mathura'),(41,51,'2023-02-04 23:37:18','System',729,'khushi','djjd'),(42,54,'2023-02-04 23:57:40','System',8383,'khushi jha','noida'),(59,2,'2023-02-08 22:00:02','System',987694930,'Pankaj','Gaziabad'),(61,39,'2023-02-08 22:44:41','System',2929,'virat','noida'),(62,51,'2023-02-08 22:45:00','System',729,'rahul','noida'),(63,56,'2023-02-08 22:45:21','System',72965645,'sumit','ggn'),(69,39,'2023-02-10 06:40:05','System',399,'roy','noida'),(70,35,'2023-02-10 06:54:12','System',3838,'rahul','noida'),(71,33,'2023-02-10 06:55:21','System',8282,'vinod','noida'),(73,21,'2023-02-10 11:45:59','System',7299,'khushii','spu'),(74,87,'2023-02-11 09:09:48','System',877,'praksh','delhi'),(75,87,'2023-02-11 09:12:06','System',333,'ashok','ff'),(76,10,'2023-02-12 08:05:40','System',8888888888,'testing','Delhi'),(77,102,'2023-02-12 08:06:34','System',8888888889,'testing','Delhi'),(78,102,'2023-02-12 08:07:13','System',8888888889,'testing','Delhi'),(79,102,'2023-02-12 08:07:29','System',8888888889,'testing','Delhi'),(81,108,'2023-02-12 08:17:21','System',8888888889,'testing reload','Delhi'),(82,102,'2023-02-12 08:23:23','System',8888888889,'testing','Delhi'),(83,102,'2023-02-12 08:29:47','System',8888888889,'sd','Delhi'),(88,102,'2023-02-12 10:23:16','System',8888888889,'testing','Delhi'),(89,102,'2023-02-12 10:34:11','System',8888888811,'testing_reload','ssss'),(90,222,'2023-02-13 07:03:59','System',8888888889,'testing','Delhi'),(91,222,'2023-02-16 05:45:42','System',8888888889,'test','Delhi');
/*!40000 ALTER TABLE `partymaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productmaster`
--

DROP TABLE IF EXISTS `productmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `productmaster` (
  `ProductId` int(11) NOT NULL AUTO_INCREMENT,
  `BrandName` varchar(200) DEFAULT NULL,
  `BatteryType` varchar(100) DEFAULT NULL,
  `GauranteePeriod` int(11) DEFAULT NULL,
  `CreateDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` varchar(45) DEFAULT '(''System'')',
  PRIMARY KEY (`ProductId`),
  KEY `PK_ProductId` (`ProductId`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productmaster`
--

LOCK TABLES `productmaster` WRITE;
/*!40000 ALTER TABLE `productmaster` DISABLE KEYS */;
INSERT INTO `productmaster` VALUES (3,'Tubular Plate','BT-004',2,'2023-02-02 09:29:59','(\'System\')'),(8,'Tubular Plate','BT-004',2,'2023-02-02 09:35:56','(\'System\')'),(9,'microtex','BT- 1111',4,'2023-02-05 00:27:58','(\'System\')'),(19,'Exide','BT-89',8,'2023-02-08 21:18:18','(\'System\')'),(22,'Lenovo','BT-008',2,'2023-02-08 21:58:09','(\'System\')'),(23,'hitachi','BT- 7555',8,'2023-02-08 23:00:13','(\'System\')');
/*!40000 ALTER TABLE `productmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `replace`
--

DROP TABLE IF EXISTS `replace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `replace` (
  `ReplaceId` int(11) NOT NULL AUTO_INCREMENT,
  `SaleId` int(11) DEFAULT NULL,
  `NewSrNo` varchar(45) DEFAULT NULL,
  `ReplacementDate` datetime DEFAULT NULL,
  `PartyId` int(11) DEFAULT NULL,
  `CreateDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` varchar(45) DEFAULT NULL,
  `ProductId` int(11) NOT NULL,
  PRIMARY KEY (`ReplaceId`),
  KEY `Fk_replace_Product` (`ProductId`),
  KEY `Fk_replace_PartyMaster` (`PartyId`),
  KEY `Fk_replace_sale` (`SaleId`),
  CONSTRAINT `Fk_replace_PartyMaster` FOREIGN KEY (`PartyId`) REFERENCES `partymaster` (`PartyMasterId`),
  CONSTRAINT `Fk_replace_Product` FOREIGN KEY (`ProductId`) REFERENCES `productmaster` (`ProductId`),
  CONSTRAINT `Fk_replace_sale` FOREIGN KEY (`SaleId`) REFERENCES `sales` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `replace`
--

LOCK TABLES `replace` WRITE;
/*!40000 ALTER TABLE `replace` DISABLE KEYS */;
INSERT INTO `replace` VALUES (4,24,'ROBOC231','2023-02-02 00:00:00',15,'2023-02-13 20:08:05',NULL,3);
/*!40000 ALTER TABLE `replace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ProductId` int(11) DEFAULT NULL,
  `PartyId` int(11) DEFAULT NULL,
  `SaleDate` date DEFAULT NULL,
  `CreateDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` varchar(45) DEFAULT NULL,
  `BatterySrNo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Pk_SalesId` (`id`),
  KEY `IX_ProductId` (`ProductId`),
  KEY `IX_ApplicationUserid` (`PartyId`),
  CONSTRAINT `Fk_sales_PartyMaster` FOREIGN KEY (`PartyId`) REFERENCES `partymaster` (`PartyMasterId`),
  CONSTRAINT `Fk_sales_Product` FOREIGN KEY (`ProductId`) REFERENCES `productmaster` (`ProductId`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (24,3,15,'2023-02-02','2023-02-09 00:00:00','System','RB3451008'),(25,9,15,'2023-02-23','2023-02-08 00:00:00','System','RB3451124'),(26,22,15,'2023-02-17','2023-02-08 00:00:00','System','RB3451124'),(27,22,59,'2023-02-17','2023-02-08 00:00:00','System','RB3451124');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salesstaging`
--

DROP TABLE IF EXISTS `salesstaging`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salesstaging` (
  `BrandName` varchar(100) DEFAULT NULL,
  `BatteryType` varchar(50) DEFAULT NULL,
  `PartyId` varchar(100) DEFAULT NULL,
  `BatterySrNo` varchar(50) DEFAULT NULL,
  `SaleDate` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salesstaging`
--

LOCK TABLES `salesstaging` WRITE;
/*!40000 ALTER TABLE `salesstaging` DISABLE KEYS */;
INSERT INTO `salesstaging` VALUES ('AUTOMOTIVE','SA-40Z','Automative Battery','RB3451008','2/2/2023 12:00:00 AM'),('AUTOMOTIVE','SA-40','Automative Battery','RB3451009','2/3/2023 12:00:00 AM'),('AUTOMOTIVE','SA-70','Automative Battery','RB3451010','2/4/2023 12:00:00 AM'),('AUTOMOTIVE','SA-80','Automative Battery','RB3451011','2/5/2023 12:00:00 AM'),('AUTOMOTIVE','SA-85','Automative Battery','RB3451012','2/6/2023 12:00:00 AM'),('AUTOMOTIVE','SA-90','Automative Battery','RB3451013','2/7/2023 12:00:00 AM'),('AUTOMOTIVE','SA-100','Automative Battery','RB3451014','2/8/2023 12:00:00 AM'),('AUTOMOTIVE','SA-135','Automative Battery','RB3451015','2/9/2023 12:00:00 AM'),('AUTOMOTIVE','SA-1500','Automative Battery','RB3451016','2/2/2023 12:00:00 AM'),('AUTOMOTIVE','SA-1500','Automative Battery','RB3451017','2/2/2023 12:00:00 AM'),('INVERTER BATTERY','STL-16048','Bindal Battery','RB3451018','2/2/2023 12:00:00 AM'),('INVERTER BATTERY','STL-18048','Bindal Battery','RB3451019','2/2/2023 12:00:00 AM'),('INVERTER BATTERY','STL-19048','Bindal Battery','RB3451020','2/2/2023 12:00:00 AM'),('INVERTER BATTERY','STT-15048','Bindal Battery','RB3451021','2/2/2023 12:00:00 AM'),('INVERTER BATTERY','STT-15548','Bindal Battery','RB3451022','2/2/2023 12:00:00 AM'),('INVERTER BATTERY','STT-17060','Bindal Battery','RB3451023','2/2/2023 12:00:00 AM'),('INVERTER BATTERY','STT-19060','Bindal Battery','RB3451024','2/2/2023 12:00:00 AM'),('INVERTER BATTERY','STT-22560','Bindal Battery','RB3451025','2/5/2023 12:00:00 AM'),('INVERTER BATTERY','STT-26060','Bindal Battery','RB3451026','2/5/2023 12:00:00 AM'),('INVERTER BATTERY','STT-30260','Bindal Battery','RB3451027','2/5/2023 12:00:00 AM'),('E-RICKSHAW BATTERY','ER-17000','Bindal Battery','RB3451028','2/5/2023 12:00:00 AM'),('E-RICKSHAW BATTERY','ER-2300','Bindal Battery','RB3451029','2/5/2023 12:00:00 AM'),('E-RICKSHAW BATTERY','ER-25000','Jain Battery','RB3451030','2/9/2023 12:00:00 AM'),('AUTOMOTIVE ','NS-40Z','Jain Battery','RB3451031','2/9/2023 12:00:00 AM'),('AUTOMOTIVE ','NS-40Z','Jain Battery','RB3451032','2/9/2023 12:00:00 AM'),('AUTOMOTIVE ','N-70','Jain Battery','RB3451033','2/9/2023 12:00:00 AM'),('AUTOMOTIVE ','N-80','Jain Battery','RB3451034','2/9/2023 12:00:00 AM'),('AUTOMOTIVE ','N-85','Jain Battery','RB3451035','2/9/2023 12:00:00 AM'),('AUTOMOTIVE ','N-90','Jain Battery','RB3451036','2/9/2023 12:00:00 AM'),('AUTOMOTIVE ','N-100','Jain Battery','RB3451037','2/9/2023 12:00:00 AM'),('AUTOMOTIVE ','N-135','Jain Battery','RB3451038','2/9/2023 12:00:00 AM'),('AUTOMOTIVE ','N-1500','Jain Battery','RB3451039','2/3/2023 12:00:00 AM'),('AUTOMOTIVE ','N-150','Jain Battery','RB3451040','2/3/2023 12:00:00 AM'),('INVERTER BATTERY','ETL-16500','Jain Battery','RB3451041','2/3/2023 12:00:00 AM'),('INVERTER BATTERY','ETL-18000','Shyama Battery','RB3451042','2/3/2023 12:00:00 AM'),('INVERTER BATTERY','ETL-21000','Shyama Battery','RB3451043','2/4/2023 12:00:00 AM'),('INVERTER BATTERY','BT-1450','Shyama Battery','RB3451044','2/4/2023 12:00:00 AM'),('INVERTER BATTERY','BT-500','Shyama Battery','RB3451045','2/4/2023 12:00:00 AM'),('INVERTER BATTERY','BT-16000','Shyama Battery','RB3451046','2/4/2023 12:00:00 AM'),('INVERTER BATTERY','BT-18000','Shyama Battery','RB3451047','2/4/2023 12:00:00 AM'),('INVERTER BATTERY','BT-22000','Shyama Battery','RB3451048','2/4/2023 12:00:00 AM'),('INVERTER BATTERY','BT-26000','Shyama Battery','RB3451049','2/4/2023 12:00:00 AM'),('INVERTER BATTERY','BT-30000','Shyama Battery','RB3451050','2/4/2023 12:00:00 AM'),('E-RICKSHAW BATTERY','ER-17000','Shyama Battery','RB3451051','2/4/2023 12:00:00 AM'),('E-RICKSHAW BATTERY','ER-2200','Shyama Battery','RB3451052','2/4/2023 12:00:00 AM');
/*!40000 ALTER TABLE `salesstaging` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `warantymaster`
--

DROP TABLE IF EXISTS `warantymaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warantymaster` (
  `WarrantyId` int(11) NOT NULL AUTO_INCREMENT,
  `ProductId` int(11) DEFAULT NULL,
  `PartyMatserId` int(11) DEFAULT NULL,
  `GracePeriod` int(11) DEFAULT NULL,
  `CreateDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` varchar(45) DEFAULT '(''System'')',
  PRIMARY KEY (`WarrantyId`),
  KEY `Fk_WarrantyMaster_PartyMaster` (`PartyMatserId`),
  KEY `Fk_WarrantyMaster_Product` (`ProductId`),
  CONSTRAINT `Fk_WarrantyMaster_PartyMaster` FOREIGN KEY (`PartyMatserId`) REFERENCES `partymaster` (`PartyMasterId`),
  CONSTRAINT `Fk_WarrantyMaster_Product` FOREIGN KEY (`ProductId`) REFERENCES `productmaster` (`ProductId`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warantymaster`
--

LOCK TABLES `warantymaster` WRITE;
/*!40000 ALTER TABLE `warantymaster` DISABLE KEYS */;
INSERT INTO `warantymaster` VALUES (32,9,22,45,'2023-02-05 09:05:20','(\'System\')'),(34,3,15,2,'2023-02-14 08:11:46','(\'System\')'),(37,3,22,2,'2023-02-16 05:46:54','(\'System\')');
/*!40000 ALTER TABLE `warantymaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'bindalbattery'
--
/*!50003 DROP PROCEDURE IF EXISTS `SP_InsertSalesStg` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`bindalbatterry`@`%` PROCEDURE `SP_InsertSalesStg`(
BrandName VARCHAR(100),
BatteryType VARCHAR(50),
PartyId VARCHAR(100),
BatterySrNo VARCHAR(50),
SaleDate VARCHAR(50)
)
BEGIN
 INSERT INTO salesstaging(BrandName,BatteryType,PartyId,BatterySrNo,SaleDate) 
        VALUES(BrandName,BatteryType,PartyId, BatterySrNo,  SaleDate );
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-26 20:22:10
